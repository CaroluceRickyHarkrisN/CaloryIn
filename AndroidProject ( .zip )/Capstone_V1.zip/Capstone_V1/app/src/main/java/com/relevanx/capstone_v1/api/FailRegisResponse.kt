package com.relevanx.capstone_v1.api

import com.google.gson.annotations.SerializedName

data class FailRegisResponse(

	@field:SerializedName("message")
	val message: String? = null
)
