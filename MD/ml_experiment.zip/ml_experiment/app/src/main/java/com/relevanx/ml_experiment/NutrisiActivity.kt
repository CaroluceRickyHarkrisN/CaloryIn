package com.relevanx.ml_experiment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.relevanx.ml_experiment.databinding.ActivityNutrisiBinding

class NutrisiActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNutrisiBinding
    private lateinit var viewModel: FoodSearchViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNutrisiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[FoodSearchViewModel::class.java]
        viewModel.api.observe(this) { api ->
            setNutri(api)
        }

        viewModel.isLoading.observe(this) {
            showLoading(it)
        }

        intent.getStringExtra(EXTRA_NAME)?.let {
            viewModel.searchFoods(it)
        }
    }

    private fun setNutri(api: UsdaResponse?) {
        var deskripsi = "Description :  ${api?.foods?.get(0)?.description.toString()}"
        binding.n1.text = deskripsi

        var energi = "${api?.foods?.get(0)?.foodNutrients?.get(3)?.nutrientName} : ${api?.foods?.get(0)?.foodNutrients?.get(3)?.nutrientNumber} ${api?.foods?.get(0)?.foodNutrients?.get(3)?.unitName}"
        binding.n2.text = energi

        var protein = "${api?.foods?.get(0)?.foodNutrients?.get(0)?.nutrientName} : ${api?.foods?.get(0)?.foodNutrients?.get(0)?.nutrientNumber} ${api?.foods?.get(0)?.foodNutrients?.get(0)?.unitName}"
        binding.n3.text = protein

        var lemak = "${api?.foods?.get(0)?.foodNutrients?.get(1)?.nutrientName} : ${api?.foods?.get(0)?.foodNutrients?.get(1)?.nutrientNumber} ${api?.foods?.get(0)?.foodNutrients?.get(1)?.unitName}"
        binding.n4.text = lemak

        var karbohidrat = "${api?.foods?.get(0)?.foodNutrients?.get(2)?.nutrientName} : ${api?.foods?.get(0)?.foodNutrients?.get(2)?.nutrientNumber} ${api?.foods?.get(0)?.foodNutrients?.get(2)?.unitName}"
        binding.n5.text = karbohidrat

        var serat = "${api?.foods?.get(0)?.foodNutrients?.get(5)?.nutrientName} : ${api?.foods?.get(0)?.foodNutrients?.get(5)?.nutrientNumber} ${api?.foods?.get(0)?.foodNutrients?.get(5)?.unitName}"
        binding.n6.text = serat
    }

    private fun showLoading(state: Boolean) { binding.progressBar.visibility = if (state) View.VISIBLE else View.GONE }

    companion object {
        const val EXTRA_NAME = "extra_name"
        var token: String? = null
        var storyId: String? = null
    }
}