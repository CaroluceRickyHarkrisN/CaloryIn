package com.relevanx.capstone_v1

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationBarView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.relevanx.capstone_v1.databinding.ActivityHomeBinding
import ir.mahozad.android.PieChart

class Home : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    lateinit var mGoogleSignInClient: GoogleSignInClient
    private lateinit var userPreference: UserPreference


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userPreference = UserPreference(this)

        bottom()

        val uid = Firebase.auth.currentUser?.uid.toString()
        val email = Firebase.auth.currentUser?.email.toString()
        val name = Firebase.auth.currentUser?.displayName.toString()
        binding.textView2.text = uid
        binding.textView.text = email
        binding.textView3.text = name

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("253869776960-cs1hdeqo3rpnpm10ibokm8fqh695l6ov.apps.googleusercontent.com")
            .requestEmail()
            .build()
        mGoogleSignInClient= GoogleSignIn.getClient(this,gso)

        val pieChart = findViewById<PieChart>(R.id.pieChart)
//        pieChart.slices = listOf(
//            PieChart.Slice(0.2f, Color.BLUE),
//            PieChart.Slice(0.4f, Color.MAGENTA),
//            PieChart.Slice(0.3f, Color.YELLOW),
//            PieChart.Slice(0.1f, Color.CYAN),
//        )

        pieChart.apply {
            slices = listOf(
                PieChart.Slice(
                    0.3f,
                    Color.rgb(120, 181, 0),
                    Color.rgb(149, 224, 0),
                    "Lemak"
                ),
                PieChart.Slice(
                    0.2f,
                    Color.rgb(204, 168, 0),
                    Color.rgb(249, 228, 0),
                    "Protein"
                ),
                PieChart.Slice(
                    0.2f,
                    Color.rgb(0, 162, 216),
                    Color.rgb(31, 199, 255),
                    "Karbo"
                ),
                PieChart.Slice(
                    0.17f,
                    Color.rgb(255, 4, 4),
                    Color.rgb(255, 72, 86),
                    "Serat"
                ),
                PieChart.Slice(
                    0.13f,
                    Color.rgb(255, 255, 255),
                    Color.rgb(255, 255, 255)
                )
            )
            startAngle = 0
            labelType = PieChart.LabelType.OUTSIDE_CIRCULAR
            labelIconsPlacement = PieChart.IconPlacement.START
            gradientType = PieChart.GradientType.RADIAL
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.logout -> {
                mGoogleSignInClient.signOut().addOnCompleteListener {
                    val intent= Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
                Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }


    private fun bottom() {
        binding.fabCamera.setOnClickListener {
            val intent = Intent(this, CameraActivity::class.java)
            startActivity(intent)
            finish()
        }

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigationView.selectedItemId = R.id.bottom_home
        BottomNavigationHelper.setupBottomNavigation(this)
    }

    companion object {
        private var token: String? = null
        var token2: String = ""
    }

}
