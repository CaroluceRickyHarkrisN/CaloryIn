package com.relevanx.capstone_v1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class BottomNavigationHelper {
    companion object {
        fun setupBottomNavigation(activity: AppCompatActivity) {

            val bottomNavigationView = activity.findViewById<BottomNavigationView>(R.id.bottomNavigationView)
            bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
                when (menuItem.itemId) {
                    R.id.bottom_home -> {
                        // Handle Home menu item click
                        if (activity !is Home) {
                            activity.startActivity(Intent(activity, Home::class.java))
                            activity.finish()
                        }
                        true
                    }
                    R.id.bottom_history -> {
                        // Handle History menu item click
                        if (activity !is HistoryActivity) {
                            activity.startActivity(Intent(activity, HistoryActivity::class.java))
                            activity.finish()
                        }
                        true
                    }
                    R.id.bottom_task -> {
                        // Handle Task menu item click
                        if (activity !is ChallangeActivity) {
                            activity.startActivity(Intent(activity, ChallangeActivity::class.java))
                            activity.finish()
                        }
                        true
                    }
                    R.id.bottom_profile -> {
//
                        if (activity !is ProfileActivity) {
                            activity.startActivity(Intent(activity, ProfileActivity::class.java))
                            activity.finish()
                        }
                        true
                    }
                    else -> false
                }
            }
        }
    }
}
