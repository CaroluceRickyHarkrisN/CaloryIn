package com.relevanx.capstone_v1

class BottomNav {
}