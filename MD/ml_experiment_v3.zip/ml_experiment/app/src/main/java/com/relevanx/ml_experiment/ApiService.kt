package com.relevanx.ml_experiment

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("foods/search")
    fun searchFoods(
        @Query("api_key") apiKey: String,
        @Query("query") query: String
    ): Call<UsdaResponse>
}