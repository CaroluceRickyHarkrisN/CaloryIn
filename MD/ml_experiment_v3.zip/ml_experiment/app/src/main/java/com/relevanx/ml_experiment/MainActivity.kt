package com.relevanx.ml_experiment

import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import com.relevanx.ml_experiment.databinding.ActivityMainBinding
import com.relevanx.ml_experiment.ml.TfliteModel
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var bitmap: Bitmap
    companion object {
        var name:String? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)



        binding.selectBtn.setOnClickListener {
            val intent = Intent()
            intent.action = Intent.ACTION_GET_CONTENT
            intent.type = "image/*"
            startActivityForResult(intent, 100)
        }

        binding.cameraBtn.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(intent, 101)
        }


        binding.predictBtn.setOnClickListener {
            val imageProcessor = ImageProcessor.Builder()
                .add(ResizeOp(150, 150, ResizeOp.ResizeMethod.BILINEAR))
                .build()

            val labels =  application.assets.open("labels.txt").bufferedReader().readLines()

            val model = TfliteModel.newInstance(this)

            val tensorImage = TensorImage(DataType.FLOAT32)
            tensorImage.load(bitmap)

            val processedImage = imageProcessor.process(tensorImage)

            val inputFeature0 = TensorBuffer.createFixedSize(intArrayOf(1, 150, 150, 3), DataType.FLOAT32)
            inputFeature0.loadBuffer(processedImage.buffer)

            val outputs = model.process(inputFeature0)
            val outputFeature0 = outputs.outputFeature0AsTensorBuffer

            var maxIdx = 0
            outputFeature0.floatArray.forEachIndexed { idx, fl ->
                if (fl > outputFeature0.floatArray[maxIdx]) {
                    maxIdx = idx
                }
            }

            name = labels[maxIdx]
            binding.resView.text = name
        }

    }


    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_OK) {
            when (requestCode) {
                100 -> {
                    // Gallery selection
                    val uri = data?.data
                    bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, uri)
                    binding.imageView.setImageBitmap(bitmap)
                }
                101 -> {
                    // Camera capture
                    bitmap = data?.extras?.get("data") as Bitmap
                    binding.imageView.setImageBitmap(bitmap)
                }
            }
        }
    }

}